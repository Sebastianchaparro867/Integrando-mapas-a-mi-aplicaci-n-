package com.anncode.aplicacioncontactos.presentador;

/**
 * Created by anahisalgado on 21/04/16.
 */
public interface IRecylerViewFragmentPresenter {

    public void obtenerContactosBaseDatos();
    void obtenerMediosRecientes();

    public void mostrarContactosRV();
}
